#include <iostream>
#include <cstdio>

using namespace std;

int main() {
    int a,b;
    cin >> a >> b;
    cout << 3;
    return 0;
}