rm judge
g++ judge.cpp -O2 -o judge
./judge < data.in > data.out