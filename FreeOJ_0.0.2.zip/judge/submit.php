<?php

function judge($code,$path){
  //echo $path;
  unlink ("judge");
  unlink ("data.in");
  unlink ("data.out");
  unlink ("judge.cpp");

  $file = fopen("judge.cpp","w+") or exit("Unable to Open CPP.");
  fwrite($file,$code);
  fclose($file);

  if (!is_file($path)) exit("Bad Problem ID!");

  copy($path,"./data.in");

  system("./judge.sh");

  $fout = fopen("data.out","r") or exit("Unable to Open File.");
  $ret = "";
  while (!feof($fout)){
    $ret = $ret . fgets($fout);
    //echo $ret;
  }
  fclose($fout);
  return $ret;
}

$code = $_POST["code"];
$pid = $_POST["pid"];

$curj = 1;
$p_fnt = "../problems/" . $pid . "/";

while (is_file($p_fnt . "data" . (string)($curj) . ".in")){
  //echo $p_fnt . "data" . (string)($curj) . ".in";
  judge($code,$p_fnt . "data" . (string)($curj) . ".in");
  
  $file1 = md5_file("./data.out");
  $file2 = md5_file($p_fnt . "data" . (string)($curj) . ".out");
  
  if ($file1 == $file2)
     echo "AC<br>";
  else
     echo "WA<br>";
  
  
  $curj = $curj + 1;
}

?>
