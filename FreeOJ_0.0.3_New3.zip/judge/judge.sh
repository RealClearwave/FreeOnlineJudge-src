rm judge
g++ judge.cpp -O2 -o judge
timeout 1 ./judge < data.in > data.out