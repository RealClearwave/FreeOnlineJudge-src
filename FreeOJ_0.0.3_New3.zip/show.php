<?php

$probid = $_GET["pid"];
$cover = "./problems/" . $probid . "/cover.html";

if (!is_file($cover)) exit("Bad Problem ID!");

$file = fopen($cover,"r") or exit("Bad Cover!");

echo "<h3>Problem id:" . (string)$probid . "</h3>";

while (!feof($file)){
  echo fgets($file);
}

fclose($file);

echo "<a href=\"judge/submit.html\">Submit</a>";

?>