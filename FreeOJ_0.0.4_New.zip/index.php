<?php
require ("./library/prbinfo.php");
exec("ls ./problems",$prbs);
$cur = "";
foreach ($prbs as $cur)
  echo "<a href=\"show.php?pid=" . $cur . "\">" . get_prb_name((int)($cur)) . "</a>";