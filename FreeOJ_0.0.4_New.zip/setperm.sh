chown -R www-data ./judge
chmod -R 755 ./judge
