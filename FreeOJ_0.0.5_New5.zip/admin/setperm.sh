chown -R www-data ../submissions
chmod -R 755 ../submissions
