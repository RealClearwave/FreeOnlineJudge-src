<?php
require ("./library/prbinfo.php");
$probid = $_GET["pid"];
$cover = "./problems/" . $probid . "/cover.html";

if (!is_file($cover)) exit("Bad Problem ID!");

$file = fopen($cover,"r") or exit("Bad Cover!");

echo "<h5>Problem id: " . (string)$probid . " </h5>";
echo "<h4>Name: " . get_prb_name($probid) . " </h4>";
echo "<h4>Time Limit: " . get_prb_time_limit($probid) . " seconds</h4>";

while (!feof($file)){
  echo fgets($file);
}

fclose($file);

echo "<a href=\"submit.php\">Submit</a>";

?>