<?php
require ("./library/filesys.php");
$j_path = "submissions/judge" . md5(uniqid(microtime(true),true));
copydir("./judge-module",$j_path);
header('location:' . $j_path . "/submit.html");