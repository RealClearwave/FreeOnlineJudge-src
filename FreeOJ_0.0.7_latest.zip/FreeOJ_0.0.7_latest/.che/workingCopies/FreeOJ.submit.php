<?php
require ("./library/filesys.php");
require ("./library/libuser.php");

if (!auth_cookie()){
    //header('location:' . "user/login.html");
}else{
    $j_path = "submissions/judge" . md5(uniqid(microtime(true),true));
    copydir("./judge-module",$j_path);
    header('location:' . $j_path . "/submit.html");
}