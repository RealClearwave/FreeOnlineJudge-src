chown -R www-data ../submissions ../user/database
chmod -R 755 ../submissions
