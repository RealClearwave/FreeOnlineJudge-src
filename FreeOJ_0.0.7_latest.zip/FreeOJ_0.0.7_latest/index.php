<?php
require ("./library/prbinfo.php");
exec("ls ./problems",$prbs);
$cur = "";
echo "<table border=\"1\">";
foreach ($prbs as $cur){
  echo "<tr>";
  echo "<td>" . $cur . "</td>";
  echo "<td><a href=\"show.php?pid=" . $cur . "\">" . get_prb_name((int)($cur)) . "</a></td>";
}