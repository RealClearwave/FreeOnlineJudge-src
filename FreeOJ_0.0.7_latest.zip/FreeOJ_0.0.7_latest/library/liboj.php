function get_oj_info(){
    $file = fopen("./ojcfg.json","r");
    $attr = fgets($file);
    return json_decode($attr,true);
}