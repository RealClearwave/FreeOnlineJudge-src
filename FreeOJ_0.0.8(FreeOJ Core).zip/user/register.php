<?php
require ("../library/libuser.php");
$name = $_POST["name"];
$passwd = $_POST["passwd"];

echo "Your UID is " . create_user($name,$passwd);