<?php
echo "<html><head><meta charset=\"utf-8\"><title>Status</title><link rel=\"stylesheet\" href=\"https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css\">";
echo "<script src=\"https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js\"></script><script src=\"https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script></head>";
echo "<body><nav class=\"navbar navbar-default\" role=\"navigation\"><div class=\"container-fluid\"><div class=\"navbar-header\"><a class=\"navbar-brand\" href=\"index.html\">OJ</a>";
echo "</div><div><ul class=\"nav navbar-nav\"><li><a href=\"problemset.php\">Problemset</a></li><li><a href=\"submit.php\">Submit</a></li><li class=\"active\"><a href=\"status.php\">Status</a></li>";

echo "</ul><ul class=\"nav navbar-nav navbar-right\"><li class=\"dropdown\">";
echo "<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">User<strong class=\"caret\"></strong></a>";
echo "<ul class=\"dropdown-menu\"><li><a href=\"user/dashboard.html\">Dashboard</a>";
echo "</li><li><a href=\"user/login.html\">Login</a></li><li>";
echo "<a href=\"user/register.html\">Register</a></li><li class=\"divider\">";
echo "</li><li><a href=\"user/login.php?logout=true\">Logout</a></li></ul></li></ul>";
echo "</div></div></nav>";

echo "<table class=\"table\"><caption>Status</caption>";
echo "<thead><tr><th>Run ID</th><th>Status</th><th>Detail</th></tr></thead><tbody>";
exec("ls -tr ./submissions",$stl);
//"<tr class=\"warning\"><td>All</td><td>CE</td></tr>"
foreach ($stl as $cur){
    //echo $cur . "<br>";
    //if (file_exists("./submissions/" . $cur . "/unused"))
        //echo "<tr class=\"warning\"><td>" . $cur . "</td><td>Submitting/Judgement Failed</td>" . "<td><a href=\"submissions/" . $cur . "/result.html\">More</a></td></tr>";
    /*else*/if (file_exists("./submissions/" . $cur . "/accepted"))
        echo "<tr class=\"success\"><td>" . $cur . "</td><td>Accepted</td>" . "<td><a href=\"submissions/" . $cur . "/result.html\">More</a></td></tr>";
    elseif (file_exists("./submissions/" . $cur . "/unaccepted"))
        echo "<tr class=\"danger\"><td>" . $cur . "</td><td>Unaccepted</td>" . "<td><a href=\"submissions/" . $cur . "/result.html\">More</a></td></tr>";
    else
        echo "<tr class=\"active\"><td>" . $cur . "</td><td>Judging</td>" . "<td>Detail(unavailable)</td></tr>";
}

echo "</tbody></table></body></html>";
