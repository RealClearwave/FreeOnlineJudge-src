<?php
require ("../library/libuser.php");
if (isset($_GET["uid"])){
    $uid = $_GET["uid"];

}else if (auth_cookie()){
    $uid = cookie_uid();
}else{
    header('location:' . "login.html");
}

echo "<head><meta charset=\"utf-8\"><title>About this User</title>";
echo "<link rel=\"stylesheet\" href=\"https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css\">";
echo "<script src=\"https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js\"></script>";
echo "<script src=\"https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script></head>";

echo "<body><nav class=\"navbar navbar-default\" role=\"navigation\"><div class=\"container-fluid\"><div class=\"navbar-header\"><a class=\"navbar-brand\" href=\"/index.html\">OJ</a>";
echo "</div><div><ul class=\"nav navbar-nav\"><li><a href=\"/problemset.php\">Problemset</a></li><li><a href=\"/submit.php\">Submit</a></li><li><a href=\"/status.php\">Status</a></li>";

echo "</ul><ul class=\"nav navbar-nav navbar-right\"><li class=\"dropdown\">";
echo "<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">User<strong class=\"caret\"></strong></a>";
echo "<ul class=\"dropdown-menu\"><li><a href=\"user/dashboard.html\">Dashboard</a>";
echo "</li><li><a href=\"login.html\">Login</a></li><li>";
echo "<a href=\"register.html\">Register</a></li><li class=\"divider\">";
echo "</li><li><a href=\"login.php?logout=true\">Logout</a></li></ul></li></ul>";
echo "</div></div></nav>";

echo "<div class=\"container\"><div class=\"row clearfix\"><div class=\"col-md-12 column\"><div class=\"jumbotron\">";
echo "<h1>Hello,". get_user_name($uid)  ."</h1>";
echo "<p>" . get_user_intr($uid) . "</p>";

echo "</div><table class=\"table table-hover\"><caption>Submitting Record</caption><thead>";
echo "<tr><th>ID</th><th>Problem ID</th></tr></thead><tbody>";
$cj = 0;
foreach (get_user_record($uid) as $cur){
    $cj = $cj + 1;
    echo "<tr class=\"active\"><td>" . (string)($cj) . "</td><td>" . $cur . "</td></tr>";
    //echo $cur . "     ";
}

echo "</tbody></table></div></div></div></body>";
