<?php
require_once ("../library/libuser.php");

if (!auth_cookie()) header("location:/user/login.html");

$uid = cookie_uid();

if (isset($_POST["nname"])){
    //Modify Username
    set_user_name($uid,$_POST["nname"]);
}

if (isset($_POST["npasswd"])){
    //Modify Passwd
    set_user_passwd($uid,$_POST["npasswd"]);
}

if (isset($_POST["nintr"])){
    //Modify Introduction
    set_user_intr($uid,$_POST["nintr"]);
}

header("location:dashboard.html");