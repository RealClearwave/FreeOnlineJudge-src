<?php
require_once ("../library/libuser.php");
$uid = $_POST["uid"];
$passwd = $_POST["passwd"];

//echo $_SERVER["HTTP_REFERER"];
if (isset($_GET["logout"])){
    $expire=time()-2*60*60*24*30;
    setcookie("uid", "", $expire,'/');
    setcookie("passwd","",$expire,'/');
    header("Location:login.html");
}elseif (auth_user($uid,$passwd)){
    echo "<h1>Hello " . get_user_name($uid) . "</h1>";
    $expire=time()+60*60*24*30;
    setcookie("uid", $uid, $expire,'/');
    setcookie("passwd",$passwd,$expire,'/');
    print_r($_COOKIE);
    header("Location:show.php");
}else{
    echo "<h1>Bad Login!</h1>";
}