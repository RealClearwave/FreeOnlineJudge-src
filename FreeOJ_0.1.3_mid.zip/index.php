<?php
require_once("library/libui.php");
require_once("library/liboj.php");
require_once("library/liblog.php");

if (isset($_GET["sentence"])){
    launch_benben($_GET["sentence"]);
    header("location:index.php");
    exit("");
}

if (isset($_GET["cben"])){
    if (!auth_cookie() || !auth_admin(cookie_uid())) {
        header("location:/user/login.php");
        exit("");
    }

    clear_benben();
    header("location:index.php");
    exit("");
}

echo html_head("Welcome!");
echo '<script>
        function launch_benben(){
            document.location="index.php?sentence=" + document.getElementById("sentence").value;
        }
        </script>';
echo html_navbar();

echo '<div class="container">
	<div class="row clearfix">
		<div class="col-md-12 column">
			<div class="panel-group" id="panel-173516">
				<div class="panel panel-default">
					<div class="panel-heading">
						 <a class="panel-title" data-toggle="collapse" data-parent="#panel-173516" href="#panel-element-633412">About FreeOJ</a>
					</div>
					<div id="panel-element-633412" class="panel-collapse in">
						<div class="panel-body">
							' . get_oj_intr() . '
						</div>
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading">
						 <a class="panel-title collapsed" data-toggle="collapse" data-parent="#panel-173516" href="#panel-element-469779">Official Website</a>
					</div>
					<div id="panel-element-469779" class="panel-collapse collapse">
						<div class="panel-body">
							<a href="' . $_SERVER['SERVER_NAME'] . '">' . $_SERVER['SERVER_NAME'] . '</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>';
echo '<div class="container">
	<div class="row clearfix">
		<div class="col-md-12 column"><h1>BenBen</h1>';
echo get_blog_content("benben");
echo 'Launch Benben<input id="sentence" />';
echo '<button type="button" class="btn btn-primary" onclick="launch_benben()">Launch BenBen!</button>';
if (auth_cookie() && auth_admin(cookie_uid())) echo '<a href="index.php?cben=true"><button type="button" class="btn btn-danger">Clear BenBen</button></a>';
echo html_tail();