<?php
require_once ("../library/libui.php");
require_once ("../library/libjudge.php");
require_once ("../library/filesys.php");

echo html_head("Online Status");
echo html_navbar();

if (isset($_GET["rid"])){
    $rid = $_GET["rid"];
    echo '<div class="container">
	<div class="row clearfix"><div class="col-md-12 column"><div class="row clearfix"><div class="col-md-8 column">
	<table class="table"><thead><tr><th>Test Node</th><th>Status</th></tr></thead><tbody>';
	
	$cur = 1;
	foreach (get_detail($rid) as $cst){
	    if ($cst == "Compile Error")
	       $col = "warning";
	    elseif ($cst == "Wrong Answer")
	       $col = "danger";
	    elseif ($cst == "Time Limit Exceeded")
	       $col = "info";
	    else 
	       $col = "success";
		echo '<tr class="' . $col . '"><td>' . $cur . '</td><td>' . $cst . '</td></tr>';
		$cur = $cur + 1;
	}

	echo '</tbody></table></div><div class="col-md-4 column"><h2>score</h2><h3>intr</h3><p>
		<a class="btn" href="#">Original Problem »</a></p></div></div></div></div></div>';
}else{
    echo "<table class=\"table\">";
    echo "<thead><tr><th>Run ID</th><th>Status</th><th>Detail</th></tr></thead><tbody>";
    exec("ls -t ./content",$stl);
    //"<tr class=\"warning\"><td>All</td><td>CE</td></tr>"
    foreach ($stl as $cur){
       $rid = strtok($cur,'.');
       if (get_rec_info($rid,"stat") == "Accepted")
           $col = "success";
       elseif (get_rec_info($rid,"stat") == "Unaccepted")
           $col = "danger";
       else
          $col = "warning";
    
         echo "<tr class=\"" . $col . "\"><td>" . $rid . "</td><td>" . get_rec_info($rid,"stat") . "</td><td><a href=\"show.php?rid=" . $rid . "\">More</a></td></tr>";
    }
echo "</tbody></table>";
}
echo html_tail();
