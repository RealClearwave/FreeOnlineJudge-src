<?php
define('OJROOT',str_replace('\\','/',realpath(dirname(__FILE__).'/'))."/");
function get_oj_info(){
    $file = fopen(OJROOT . "../ojcfg.json","r");
    $attr = fgets($file);
    fclose($file);
    return json_decode($attr,true);
}

function get_oj_regstat(){
    $pinfo = get_oj_info();
    //exit($pinfo["enable_register"]);
    return $pinfo["enable_register"] == "true";
}