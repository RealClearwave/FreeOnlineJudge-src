<?php
require ("./library/prbinfo.php");
require ("./library/libui.php");

$probid = $_GET["pid"];
$cover = "./problems/" . $probid . "/cover.html";

if (!is_file($cover)) exit("Bad Problem ID!");

$file = fopen($cover,"r") or exit("Bad Cover!");

echo html_head("ProblemShow - " . (string)($probid));
echo html_navbar();

echo "<div class=\"container\"><div class=\"row clearfix\"><div class=\"col-md-12 column\">";
echo "<h5>Problem id: " . (string)$probid . " </h5>";
echo "<h4>Name: " . get_prb_name($probid) . " </h4>";
echo "<h4>Time Limit: " . get_prb_time_limit($probid) . " seconds</h4>";

while (!feof($file)){
  echo fgets($file);
}
fclose($file);

echo "<a href=\"submit.php\"><button class=\"btn btn-primary\">Submit</button></a>";
echo "</div></div></div>";
echo html_tail();
?>