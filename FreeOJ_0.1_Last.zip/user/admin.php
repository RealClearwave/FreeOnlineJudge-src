<?php
require ("../library/libuser.php");

function gen_opr_link($uid){
    return '<a href="admin.php?action=delete&uid='.(string)($uid) . '">Delete this User</a><br>' . 
    '<a href="admin.php?action=cpriv&uid='.(string)($uid) . '">Admin/DeAdmin</a>';
}

function disp_adm($uid){
    if (auth_admin($uid))
        return "(admin)";
    else
        return "";
}

echo '<head>
  <title>Administration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">  
  <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
  <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
   <div class="container-fluid">
    <div class="navbar-header">
     <a class="navbar-brand" href="index.html">OJ</a>
    </div>
    <div>
     <ul class="nav navbar-nav">
      <li><a href="problemset.php">Problemset</a></li>
      <li><a href="submit.php">Submit</a></li>
      <li><a href="status.php">Status</a></li>
     </ul>
    </div>
    <ul class="nav navbar-nav navbar-right">
		<li class="dropdown">
			 <a href="#" class="dropdown-toggle" data-toggle="dropdown">User<strong class="caret"></strong></a>
				<ul class="dropdown-menu">
					<li>
						<a href="/user/dashboard.html">Dashboard</a>
					</li>
						<li>
							<a href="/user/login.html">Login</a>
						</li>
						<li>
							 <a href="/user/register.html">Register</a>
						</li>
						<li class="divider">
						</li>
						<li>
							<a href="/user/login.php?logout=true">Logout</a>
						</li>
					</ul>
		</li>
	</ul>
   </div>
  </nav>';
  
if (auth_cookie() && auth_admin(cookie_uid()))
    $aduid = cookie_uid();
else{
    echo '<div class="alert alert-danger">You are not an administrator!</div>';
    exit("");
}

if (!isset($_GET["action"])){
echo '<div class="container">
	<div class="row clearfix">
		<div class="col-md-12 column">
			<div class="panel-group" id="panel-207182">';

$cu = 0;
exec("ls ./database",$arr);
foreach ($arr as $cur){
    $cu = (int)(strtok($cur,"."));
    echo '				<div class="panel panel-default">
					<div class="panel-heading">
						 <a class="panel-title collapsed" data-toggle="collapse" data-parent="#panel-207182" href="#panel-element-' . $cu . '">User #' . $cu . ':' . get_user_name($cu) . disp_adm($cu) . '</a>
					</div>
					<div id="panel-element-' . $cu . '" class="panel-collapse collapse">
						<div class="panel-body">' . 
							 gen_opr_link($cu).
						'</div>
					</div>
				</div>';
				
	$cu = $cu + 1;
}

echo "</div></div></div></div>";
echo "</body></html>";
}else{
    if ($_GET["action"] == "delete"){
        system('rm database/' . $_GET["uid"] . '.json');
    }
    elseif ($_GET["action"] == "cpriv"){
        if (get_user_priv((int)($_GET["uid"])) == "user")
            set_user_priv((int)($_GET["uid"]),"admin");
        else
            set_user_priv((int)($_GET["uid"]),"user");
    }
    
    header("location:admin.php");
}
