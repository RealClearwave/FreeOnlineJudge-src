<?php
require ("../library/libuser.php");
require ("../library/liboj.php");
if (!get_oj_regstat()) exit("Register Disabled!");
elseif (!isset($_POST["name"]) || !isset($_POST["passwd"])) exit("Invalid Username/Password!");

$name = $_POST["name"];
$passwd = $_POST["passwd"];

echo "Your UID is " . create_user($name,$passwd);