<?php
require_once("../library/liblog.php");
require_once("../library/libui.php");

if (isset($_GET["bid"])){
    $bid = $_GET["bid"];
    echo html_head("Reading Blog - " . (string)($bid));
    echo html_navbar();
    echo get_blog_content($bid);
}else{
    echo html_head("All Blogs");
    echo html_navbar();
    
}

echo html_tail();
