<?php
require ("./library/libuser.php");
require ("./library/prbinfo.php");
require ("./library/libui.php");
require ("./library/libjudge.php");

if (isset($_POST["code"])){
$code = $_POST["code"];
$pid = $_POST["pid"];

if (!auth_cookie())
        header('location:' . "user/login.php");
else{
    $rid = Result($code,$pid);
    
    if (get_rec_info($rid,"stat") == "Accepted" && !in_array($pid,get_user_record())) {
        set_user_record(cookie_uid(),$pid);
        set_user_rank(cookie_uid(),2);
    }

    header("location:record/show.php?rid=" . $rid);
}
}else{
    echo html_head("Submit your Code");
    echo html_navbar();
    if (isset($_GET["pid"])) $pid = $_GET["pid"]; else $pid = "";
    
    echo '<div class="container" >
	<div class="row clearfix">
		<div class="col-md-12 column">
			<form role="form" action="submit.php" method="post">
				<div class="form-group">
					 <label for="pid">Problem ID</label>
					 <input type="text" class="form-control" name="pid" value="' . $pid . '" placeholder="Problem ID to submit">
				</div>
				<div class="form-group">
					 <label for="code">Your Code</label>
					<textarea class="form-control" rows="15" name="code"></textarea>
				</div>
				<button type="submit" class="btn btn-default">Submit</button>
			</form>
		</div>
	</div>
</div>';
}
?>
