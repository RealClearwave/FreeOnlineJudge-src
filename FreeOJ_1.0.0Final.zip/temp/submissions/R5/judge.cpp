int main(){
while(true);
}